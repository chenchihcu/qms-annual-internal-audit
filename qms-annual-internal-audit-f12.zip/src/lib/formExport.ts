import * as XLSX from 'xlsx'
import { EXTERNAL_AUDIT_PREP_SEED } from './externalAuditPrep'
import { downloadBlob, safeFilename } from './download'
import type {
  AppState,
  CompanyData,
  CompanyId,
  ProcedureAudit,
} from '../types'
import { COMPANY_LABELS } from '../types'

const MONTHS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']

function monthLabel(status: string | null | undefined): string {
  if (!status || typeof status !== 'string') return ''
  return status
}

function companyLabel(state: AppState, companyId: CompanyId): string {
  return state.companies[companyId].name || COMPANY_LABELS[companyId]
}

function writeWorkbook(wb: XLSX.WorkBook, filename: string): void {
  const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' })
  downloadBlob(
    new Blob([buf], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    }),
    filename,
  )
}

function sheetName(base: string): string {
  return base.slice(0, 31)
}

/** QR-28-01 年度計畫 */
export function buildAnnualPlanSheet(co: CompanyData, settings: AppState['settings']): XLSX.WorkSheet {
  const header = [
    '項次',
    '風險',
    'QP',
    '被稽核部門',
    '稽核流程',
    '對應文件',
    '負責人',
    '類型',
    '稽核人員',
    ...MONTHS,
  ]
  const title = [[`${settings.auditYear} 年度內部稽核計畫 QR-28-01 · 主任稽核員：${settings.leadAuditor}`]]
  const rows = co.planRows.map((row) => [
    row.sequence,
    row.riskLevel,
    row.qpCode,
    row.department,
    row.process,
    row.documents,
    row.owner,
    row.auditCategory,
    row.auditors,
    ...row.months.map((m) => monthLabel(m)),
  ])
  return XLSX.utils.aoa_to_sheet([...title, [], header, ...rows])
}

export function exportAnnualPlanExcel(state: AppState, companyId: CompanyId): void {
  const co = state.companies[companyId]
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, buildAnnualPlanSheet(co, state.settings), sheetName('QR-28-01'))
  const fn = safeFilename([
    'QR-28-01_年度計畫',
    companyLabel(state, companyId),
    String(state.settings.auditYear),
  ]) + '.xlsx'
  writeWorkbook(wb, fn)
}

/** QR-28-02 程序查檢表 — single audit */
export function buildAuditSheet(audit: ProcedureAudit, companyName: string): XLSX.WorkSheet {
  const meta = [
    [`${companyName} · 內部稽核查檢表 QR-28-02`],
    [`${audit.qpCode} · ${audit.process} · ${audit.auditCategory}`],
    [],
    ['被稽核部門', audit.department, '稽核流程 (QP)', `${audit.qpCode} ${audit.process}`],
    ['對應文件', audit.documents, '通知日期', audit.notifyDate],
    ['實施日期', audit.auditDate, '被稽核部門主管', audit.departmentManager],
    ['稽核人員', audit.auditors, '', ''],
    [],
    ['項目', 'NO', '稽核內容', '判定', '內容說明'],
    ...audit.items.map((item) => [
      item.category,
      item.no,
      item.content,
      item.judgment ?? '',
      item.description,
    ]),
  ]
  return XLSX.utils.aoa_to_sheet(meta)
}

export function exportAuditExcel(
  state: AppState,
  companyId: CompanyId,
  audit: ProcedureAudit,
): void {
  const wb = XLSX.utils.book_new()
  const name = sheetName(`${audit.qpCode}_${audit.department}`)
  XLSX.utils.book_append_sheet(
    wb,
    buildAuditSheet(audit, companyLabel(state, companyId)),
    name,
  )
  const fn = safeFilename([
    'QR-28-02_程序查檢表',
    companyLabel(state, companyId),
    audit.qpCode,
    audit.department,
  ]) + '.xlsx'
  writeWorkbook(wb, fn)
}

export function exportAllAuditsExcel(state: AppState, companyId: CompanyId): void {
  const co = state.companies[companyId]
  const wb = XLSX.utils.book_new()
  const label = companyLabel(state, companyId)
  for (const audit of co.audits) {
    XLSX.utils.book_append_sheet(
      wb,
      buildAuditSheet(audit, label),
      sheetName(`${audit.qpCode}_${audit.department}`),
    )
  }
  if (co.audits.length === 0) {
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['（無程序查檢表資料）']]), '空白')
  }
  const fn = safeFilename([
    'QR-28-02_全部程序查檢表',
    label,
    String(state.settings.auditYear),
  ]) + '.xlsx'
  writeWorkbook(wb, fn)
}

/** QR-28-03 不符合事項 */
export function buildNcrSheet(co: CompanyData, settings: AppState['settings']): XLSX.WorkSheet {
  const title = [[`${co.name} · ${settings.auditYear} 不符合事項清單 QR-28-03`]]
  const header = ['NCR#', 'QP', '部門', '流程', '描述', '日期', '狀態']
  const rows = co.ncrs.map((ncr) => [
    ncr.ncrNumber,
    ncr.qpCode,
    ncr.department,
    ncr.process,
    ncr.description,
    ncr.date,
    ncr.status,
  ])
  return XLSX.utils.aoa_to_sheet([...title, [], header, ...rows])
}

export function exportNcrExcel(state: AppState, companyId: CompanyId): void {
  const co = state.companies[companyId]
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, buildNcrSheet(co, state.settings), sheetName('QR-28-03'))
  const fn = safeFilename([
    'QR-28-03_不符合事項',
    companyLabel(state, companyId),
    String(state.settings.auditYear),
  ]) + '.xlsx'
  writeWorkbook(wb, fn)
}

/** 建議追蹤（optional sheet） */
export function buildSuggestionsSheet(co: CompanyData): XLSX.WorkSheet {
  const header = ['年度', '程序', '問題描述', '進度', '負責單位', '狀態']
  const rows = co.suggestions.map((s) => [
    s.year,
    s.procedure,
    s.issue,
    s.progress,
    s.responsibleUnit,
    s.status === 'open' ? '待追蹤' : '已結案',
  ])
  return XLSX.utils.aoa_to_sheet([['第三方稽核建議事項一覽表'], [], header, ...rows])
}

/** 稽核前準備（optional sheet） */
export function buildPrepSheet(state: AppState): XLSX.WorkSheet {
  const header = ['項次', '稽核前準備事項', '負責人', '九潤', '正隆興', '合併', '完成', '備註']
  const rows = EXTERNAL_AUDIT_PREP_SEED.items.map((tpl) => {
    const item = state.externalAuditPrep.items.find((i) => i.no === tpl.no)
    return [
      tpl.no,
      tpl.title,
      tpl.owner,
      item?.jiurunDone ? '是' : '',
      item?.zhenglongxingDone ? '是' : '',
      item?.mergedDone ? '是' : '',
      item?.completed ? '是' : '',
      item?.remark ?? '',
    ]
  })
  return XLSX.utils.aoa_to_sheet([
    [EXTERNAL_AUDIT_PREP_SEED.title],
    [`年度：${state.externalAuditPrep.year}`],
    [],
    header,
    ...rows,
  ])
}

/** Combined workbook — all QR forms for one company + shared prep */
export function exportAllFormsExcel(state: AppState, companyId: CompanyId): void {
  const co = state.companies[companyId]
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, buildAnnualPlanSheet(co, state.settings), sheetName('QR-28-01'))
  for (const audit of co.audits) {
    XLSX.utils.book_append_sheet(
      wb,
      buildAuditSheet(audit, companyLabel(state, companyId)),
      sheetName(`02_${audit.qpCode}`),
    )
  }
  XLSX.utils.book_append_sheet(wb, buildNcrSheet(co, state.settings), sheetName('QR-28-03'))
  XLSX.utils.book_append_sheet(wb, buildSuggestionsSheet(co), sheetName('建議追蹤'))
  XLSX.utils.book_append_sheet(wb, buildPrepSheet(state), sheetName('稽核前準備'))
  const fn = safeFilename([
    'QMS表單匯出',
    companyLabel(state, companyId),
    String(state.settings.auditYear),
  ]) + '.xlsx'
  writeWorkbook(wb, fn)
}

/** Word-friendly HTML for a single audit (opens in Word) */
export function exportAuditHtml(
  state: AppState,
  companyId: CompanyId,
  audit: ProcedureAudit,
): void {
  const companyName = companyLabel(state, companyId)
  const rows = audit.items
    .map(
      (item) =>
        `<tr><td>${esc(item.category)}</td><td>${item.no}</td><td>${esc(item.content)}</td><td>${esc(item.judgment ?? '')}</td><td>${esc(item.description)}</td></tr>`,
    )
    .join('')
  const html = `<!DOCTYPE html><html lang="zh-Hant"><head><meta charset="utf-8"><title>QR-28-02 ${esc(audit.qpCode)}</title>
<style>table{border-collapse:collapse;width:100%}td,th{border:1px solid #000;padding:4px 8px;font-size:12pt}</style></head><body>
<h2 style="text-align:center">${esc(companyName)}</h2>
<h3 style="text-align:center">內部稽核查檢表 QR-28-02</h3>
<p><b>被稽核部門：</b>${esc(audit.department)} &nbsp; <b>QP：</b>${esc(audit.qpCode)} ${esc(audit.process)}</p>
<p><b>對應文件：</b>${esc(audit.documents)} &nbsp; <b>通知日期：</b>${esc(audit.notifyDate)} &nbsp; <b>實施日期：</b>${esc(audit.auditDate)}</p>
<p><b>主管：</b>${esc(audit.departmentManager)} &nbsp; <b>稽核人員：</b>${esc(audit.auditors)}</p>
<table><thead><tr><th>項目</th><th>NO</th><th>稽核內容</th><th>判定</th><th>內容說明</th></tr></thead><tbody>${rows}</tbody></table>
</body></html>`
  const fn = safeFilename([
    'QR-28-02_程序查檢表',
    companyName,
    audit.qpCode,
    audit.department,
  ]) + '.html'
  downloadBlob(new Blob([html], { type: 'text/html;charset=utf-8' }), fn)
}

function esc(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

/** Print-ready HTML for annual plan */
export function exportAnnualPlanHtml(state: AppState, companyId: CompanyId): void {
  const co = state.companies[companyId]
  const settings = state.settings
  const monthHeaders = MONTHS.map((m) => `<th>${m}</th>`).join('')
  const body = co.planRows
    .map(
      (row) =>
        `<tr><td>${row.sequence}</td><td>${row.riskLevel}</td><td>${row.qpCode}</td><td>${esc(row.department)}</td><td>${esc(row.process)}</td><td>${esc(row.documents)}</td><td>${esc(row.owner)}</td><td>${esc(row.auditCategory)}</td><td>${esc(row.auditors)}</td>${row.months.map((m) => `<td>${monthLabel(m)}</td>`).join('')}</tr>`,
    )
    .join('')
  const html = `<!DOCTYPE html><html lang="zh-Hant"><head><meta charset="utf-8"><title>QR-28-01</title>
<style>table{border-collapse:collapse;font-size:10pt}td,th{border:1px solid #000;padding:2px 4px}</style></head><body>
<h2 style="text-align:center">${esc(companyLabel(state, companyId))}</h2>
<h3 style="text-align:center">${settings.auditYear} 年度內部稽核計畫 QR-28-01</h3>
<p style="text-align:center">主任稽核員：${esc(settings.leadAuditor)}</p>
<table><thead><tr><th>項次</th><th>風險</th><th>QP</th><th>被稽核部門</th><th>稽核流程</th><th>對應文件</th><th>負責人</th><th>類型</th><th>稽核人員</th>${monthHeaders}</tr></thead><tbody>${body}</tbody></table>
</body></html>`
  const fn = safeFilename([
    'QR-28-01_年度計畫',
    companyLabel(state, companyId),
    String(settings.auditYear),
  ]) + '.html'
  downloadBlob(new Blob([html], { type: 'text/html;charset=utf-8' }), fn)
}

/** Smoke helper — build workbook in memory without download */
export function buildExportWorkbookSmoke(state: AppState, companyId: CompanyId): XLSX.WorkBook {
  const co = state.companies[companyId]
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, buildAnnualPlanSheet(co, state.settings), 'QR-28-01')
  XLSX.utils.book_append_sheet(wb, buildNcrSheet(co, state.settings), 'QR-28-03')
  return wb
}
