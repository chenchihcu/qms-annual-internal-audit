import { describe, it, expect } from 'vitest'
import { createDemoState } from '../../data/demoData'
import {
  backupRoundTrip,
  parseBackupJson,
  serializeBackup,
  validateAppState,
  BACKUP_FORMAT,
} from '../backup'

describe('backup round-trip', () => {
  it('serializes envelope and restores full state', () => {
    const demo = createDemoState()
    const restored = backupRoundTrip(demo)
    expect(restored.version).toBe(5)
    expect(restored.companies.jiurun.audits.length).toBe(demo.companies.jiurun.audits.length)
    expect(restored.externalAuditPrep).toBeDefined()
    expect(restored.settings.auditYear).toBe(demo.settings.auditYear)
  })

  it('accepts legacy plain AppState JSON without envelope', () => {
    const demo = createDemoState()
    const legacy = JSON.stringify(demo)
    const restored = parseBackupJson(legacy)
    expect(restored.version).toBe(5)
    expect(restored.companies.zhenglongxing.planRows.length).toBeGreaterThan(0)
  })

  it('includes backup format metadata in envelope', () => {
    const demo = createDemoState()
    const parsed = JSON.parse(serializeBackup(demo)) as { _format: string; state: unknown }
    expect(parsed._format).toBe(BACKUP_FORMAT)
    expect(validateAppState(parsed.state)).toBe(true)
  })

  it('rejects invalid JSON and malformed state', () => {
    expect(() => parseBackupJson('{bad')).toThrow('JSON')
    expect(() => parseBackupJson('{"version":1}')).toThrow('不完整')
  })
})
