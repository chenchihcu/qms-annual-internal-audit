import { describe, it, expect } from 'vitest'
import * as XLSX from 'xlsx'
import { createDemoState } from '../../data/demoData'
import { buildExportWorkbookSmoke, buildAnnualPlanSheet, buildNcrSheet } from '../formExport'

describe('form export smoke', () => {
  it('builds multi-sheet workbook with QR-28-01 and QR-28-03', () => {
    const state = createDemoState()
    const wb = buildExportWorkbookSmoke(state, 'jiurun')
    expect(wb.SheetNames).toContain('QR-28-01')
    expect(wb.SheetNames).toContain('QR-28-03')
  })

  it('annual plan sheet has header row matching UI columns', () => {
    const state = createDemoState()
    const ws = buildAnnualPlanSheet(state.companies.jiurun, state.settings)
    const rows = XLSX.utils.sheet_to_json<string[]>(ws, { header: 1 })
    const header = rows.find((r) => r[0] === '項次')
    expect(header).toBeDefined()
    expect(header).toContain('QP')
    expect(header).toContain('12')
  })

  it('NCR sheet includes demo NCR row', () => {
    const state = createDemoState()
    const ws = buildNcrSheet(state.companies.jiurun, state.settings)
    const text = XLSX.utils.sheet_to_csv(ws)
    expect(text).toContain('NCR-2026-001')
    expect(text).toContain('QR-28-03')
  })
})
