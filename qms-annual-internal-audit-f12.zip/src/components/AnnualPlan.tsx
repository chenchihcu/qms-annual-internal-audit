import type { AuditStore } from '../hooks/useAuditStore'
import { exportAnnualPlanExcel, exportAnnualPlanHtml } from '../lib/formExport'
import { cycleMonthStatus } from '../lib/planner'
import { MONTH_STATUS_LEGEND, STAKEHOLDER_TAGS } from '../types'
import type { MonthStatus } from '../types'
import { Badge, Button, Card, Input } from './ui/Badge'

const MONTHS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']

function statusClass(status: MonthStatus): string {
  const found = MONTH_STATUS_LEGEND.find((l) => l.status === status)
  return found?.color ?? ''
}

function statusShort(status: MonthStatus): string {
  if (status == null) return ''
  const label = typeof status === 'string' ? status : String(status)
  if (!label) return ''
  return label === '矯正圓滿' ? '圓' : label.charAt(0)
}

export function AnnualPlan({ store }: { store: AuditStore }) {
  const { state, updateSettings, regeneratePlan, updatePlanRow, setPlanMonthStatus, updateDepartment } =
    store
  const { settings, company } = state

  return (
    <div className="space-y-6 print-area qr-form">
      <Card className="print-break">
        <div className="mb-6 flex flex-wrap items-start justify-between gap-4 no-print">
          <div>
            <h2 className="text-lg font-semibold">年度稽核計畫（QR-28-01）</h2>
            <p className="text-sm text-slate-500">程序導向編排 · 月格狀態對應紙本圖例</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={regeneratePlan}>依日期與利害關係人自動編排</Button>
            <Button variant="secondary" onClick={() => exportAnnualPlanExcel(state, state.activeCompanyId)}>
              匯出 Excel
            </Button>
            <Button variant="ghost" onClick={() => exportAnnualPlanHtml(state, state.activeCompanyId)}>
              匯出 HTML
            </Button>
          </div>
        </div>

        <div className="mb-4 flex flex-wrap gap-2 text-xs no-print">
          {MONTH_STATUS_LEGEND.map((l) => (
            <span key={l.label} className={`rounded px-2 py-1 ${l.color}`}>{l.label}</span>
          ))}
          <span className="text-slate-400">（點擊月格循環切換狀態）</span>
        </div>

        <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 no-print">
          <Input
            label="稽核年度"
            type="number"
            value={settings.auditYear}
            onChange={(v) => updateSettings({ auditYear: Number(v) })}
          />
          <Input
            label="主任稽核員"
            value={settings.leadAuditor}
            onChange={(v) => updateSettings({ leadAuditor: v })}
          />
          <Input
            label="年度起始"
            type="date"
            value={settings.yearStart}
            onChange={(v) => updateSettings({ yearStart: v })}
          />
          <Input
            label="計畫窗口起"
            type="date"
            value={settings.planWindowStart}
            onChange={(v) => updateSettings({ planWindowStart: v })}
          />
          <Input
            label="計畫窗口迄"
            type="date"
            value={settings.planWindowEnd}
            onChange={(v) => updateSettings({ planWindowEnd: v })}
          />
          <Input
            label="外部稽核日期"
            type="date"
            value={settings.externalAuditDate ?? ''}
            onChange={(v) => updateSettings({ externalAuditDate: v })}
          />
          <Input
            label="管理審查日期"
            type="date"
            value={settings.managementReviewDate ?? ''}
            onChange={(v) => updateSettings({ managementReviewDate: v })}
          />
        </div>

        <div className="print-only qr-form-header mb-4 text-center">
          <h1 className="text-xl font-bold">{company.name}</h1>
          <p>{settings.auditYear} 年度內部稽核計畫 QR-28-01 · 主任稽核員：{settings.leadAuditor}</p>
        </div>

        <div className="print-only mb-2 flex flex-wrap justify-center gap-3 text-xs">
          {MONTH_STATUS_LEGEND.map((l) => (
            <span key={l.label}>{l.label}</span>
          ))}
        </div>

        <div className="overflow-x-auto">
          <table className="qr-plan-table w-full min-w-[1000px] border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 text-left">
                <th className="border p-2">項次</th>
                <th className="border p-2">風險</th>
                <th className="border p-2">QP</th>
                <th className="border p-2">被稽核部門</th>
                <th className="border p-2">稽核流程/文件</th>
                <th className="border p-2">負責人</th>
                <th className="border p-2">類型</th>
                <th className="border p-2">稽核人員</th>
                {MONTHS.map((m) => (
                  <th key={m} className="border p-1 text-center w-8">{m}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {company.planRows.map((row) => (
                <tr key={row.id} className={row.manualOverride ? 'bg-amber-50/50' : ''}>
                  <td className="border p-2">{row.sequence}</td>
                  <td className="border p-2"><Badge label={row.riskLevel} /></td>
                  <td className="border p-2 font-medium">{row.qpCode}</td>
                  <td className="border p-2">{row.department}</td>
                  <td className="border p-2">
                    <div>{row.process}</div>
                    <div className="text-xs text-slate-500">{row.documents}</div>
                  </td>
                  <td className="border p-2">{row.owner}</td>
                  <td className="border p-2 text-xs">{row.auditCategory}</td>
                  <td className="border p-2">
                    <input
                      className="w-full rounded border border-slate-200 px-1 py-0.5 text-sm no-print"
                      value={row.auditors}
                      onChange={(e) => updatePlanRow(row.id, { auditors: e.target.value })}
                    />
                    <span className="print-only">{row.auditors}</span>
                  </td>
                  {row.months.map((status, i) => (
                    <td key={i} className="border p-0.5 text-center">
                      <button
                        type="button"
                        title={typeof status === 'string' ? status : '空白'}
                        className={`no-print h-7 w-7 rounded text-xs font-medium ${statusClass(status)}`}
                        onClick={() => setPlanMonthStatus(row.id, i, cycleMonthStatus(status))}
                      >
                        {statusShort(status)}
                      </button>
                      <span className={`print-only inline-block h-6 w-6 text-xs leading-6 ${statusClass(status)}`}>
                        {statusShort(status)}
                      </span>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card className="no-print">
        <h3 className="mb-4 text-lg font-semibold">利害關係人設定</h3>
        <div className="space-y-4">
          {company.departments.map((dept) => (
            <div key={dept.id} className="rounded-lg border border-slate-200 p-4">
              <p className="mb-2 font-medium">{dept.name} · 負責人：{dept.owner}</p>
              <div className="flex flex-wrap gap-2">
                {STAKEHOLDER_TAGS.map((tag) => {
                  const active = dept.stakeholders.includes(tag)
                  return (
                    <button
                      key={tag}
                      type="button"
                      className={`rounded-full border px-3 py-1 text-xs ${active ? 'border-blue-600 bg-blue-50 text-blue-800' : 'border-slate-200 text-slate-500'}`}
                      onClick={() => {
                        const stakeholders = active
                          ? dept.stakeholders.filter((s) => s !== tag)
                          : [...dept.stakeholders, tag]
                        updateDepartment(dept.id, { stakeholders })
                      }}
                    >
                      {tag}
                    </button>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
