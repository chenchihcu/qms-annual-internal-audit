import { useEffect, useMemo, useState } from 'react'
import type { AuditStore } from '../hooks/useAuditStore'
import { exportAllAuditsExcel, exportAuditExcel, exportAuditHtml } from '../lib/formExport'
import { scoreProcedureAudit } from '../lib/scoring'
import type { Judgment } from '../types'
import { Badge, Button, Card, Input, Select } from './ui/Badge'

const JUDGMENTS: Judgment[] = ['符合', '不符', '觀察', '不適用']

export function ProcedureAuditPanel({ store }: { store: AuditStore }) {
  const {
    state,
    getOrCreateAudit,
    updateAudit,
    updateChecklistItem,
    addChecklistItem,
    removeChecklistItem,
    ensureAllAudits,
    getProcedureTitle,
  } = store

  const { company, settings } = state
  const auditOptions = useMemo(
    () =>
      company.planRows.map((row) => ({
        value: `${row.qpCode}|${row.departmentId}`,
        label: `${row.qpCode} ${getProcedureTitle(row.qpCode, row.department)} · ${row.department}`,
      })),
    [company.planRows, getProcedureTitle],
  )

  const [selectedKey, setSelectedKey] = useState(auditOptions[0]?.value ?? '')

  useEffect(() => {
    ensureAllAudits()
  }, [ensureAllAudits])

  const [qpCode, departmentId] = selectedKey.split('|')
  const audit = qpCode && departmentId
    ? company.audits.find((a) => a.qpCode === qpCode && a.departmentId === departmentId)
      ?? getOrCreateAudit(qpCode, departmentId)
    : null

  if (!audit) {
    return <p className="text-slate-500">請先於年度計畫建立程序稽核項目</p>
  }

  const score = scoreProcedureAudit(audit, settings.scoringRules)
  const categories = [...new Set(audit.items.map((i) => i.category))]

  const handleHeaderChange = (field: string, value: string) => {
    updateAudit({ ...audit, [field]: value })
  }

  return (
    <div className="space-y-6 print-area qr-form">
      <Card>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-4 no-print">
          <h2 className="text-lg font-semibold">內部稽核查檢表（QR-28-02）</h2>
          <div className="flex flex-wrap items-end gap-2">
            <Select
              label=""
              value={selectedKey}
              onChange={setSelectedKey}
              options={auditOptions}
            />
            <Button variant="secondary" onClick={() => exportAuditExcel(state, state.activeCompanyId, audit)}>
              匯出 Excel
            </Button>
            <Button variant="ghost" onClick={() => exportAuditHtml(state, state.activeCompanyId, audit)}>
              匯出 HTML
            </Button>
            <Button variant="ghost" onClick={() => exportAllAuditsExcel(state, state.activeCompanyId)}>
              全部 Excel
            </Button>
          </div>
        </div>

        <div className="print-only qr-form-header mb-4 text-center">
          <h1 className="text-xl font-bold">{company.name}</h1>
          <p className="text-sm">內部稽核查檢表 QR-28-02</p>
          <p className="text-sm">{audit.qpCode} {getProcedureTitle(audit.qpCode, audit.department)} · {audit.auditCategory}</p>
        </div>

        <table className="qr-header-table mb-6 w-full border-collapse text-sm">
          <tbody>
            <tr>
              <td className="qr-label border p-2">被稽核部門</td>
              <td className="border p-2">{audit.department}</td>
              <td className="qr-label border p-2">稽核流程 (QP)</td>
              <td className="border p-2">{audit.qpCode} {audit.process}</td>
            </tr>
            <tr>
              <td className="qr-label border p-2">對應文件</td>
              <td className="border p-2">{audit.documents}</td>
              <td className="qr-label border p-2">通知日期</td>
              <td className="border p-2">
                <Input label="" type="date" value={audit.notifyDate} onChange={(v) => handleHeaderChange('notifyDate', v)} className="no-print" />
                <span className="print-only">{audit.notifyDate}</span>
              </td>
            </tr>
            <tr>
              <td className="qr-label border p-2">實施日期</td>
              <td className="border p-2">
                <Input label="" type="date" value={audit.auditDate} onChange={(v) => handleHeaderChange('auditDate', v)} className="no-print" />
                <span className="print-only">{audit.auditDate}</span>
              </td>
              <td className="qr-label border p-2">被稽核部門主管</td>
              <td className="border p-2">
                <Input label="" value={audit.departmentManager} onChange={(v) => handleHeaderChange('departmentManager', v)} className="no-print" />
                <span className="print-only">{audit.departmentManager}</span>
              </td>
            </tr>
            <tr>
              <td className="qr-label border p-2">稽核人員</td>
              <td className="border p-2" colSpan={3}>
                <Input label="" value={audit.auditors} onChange={(v) => handleHeaderChange('auditors', v)} className="no-print" />
                <span className="print-only">{audit.auditors}</span>
              </td>
            </tr>
          </tbody>
        </table>

        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm">程序得分：<span className="text-lg font-bold text-blue-700">{score.score}%</span></p>
          <Button variant="secondary" className="no-print" onClick={() => addChecklistItem(audit.id)}>
            新增稽核項目
          </Button>
        </div>

        <div className="overflow-x-auto">
          <table className="qr-checklist w-full border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 text-left">
                <th className="border p-2 w-24">項目</th>
                <th className="border p-2 w-12">NO</th>
                <th className="border p-2">稽核內容</th>
                <th className="border p-2 w-28">判定</th>
                <th className="border p-2">內容說明</th>
                <th className="border p-2 w-16 no-print">操作</th>
              </tr>
            </thead>
            <tbody>
              {categories.map((cat) => {
                const catItems = audit.items.filter((i) => i.category === cat)
                return catItems.map((item, idx) => (
                  <tr key={item.id} className={item.sourceYear ? 'bg-amber-50/40' : ''}>
                    {idx === 0 && (
                      <td className="border p-2 align-top font-medium" rowSpan={catItems.length}>
                        {cat}
                      </td>
                    )}
                    <td className="border p-2 align-top text-center">{item.no}</td>
                    <td className="border p-2 align-top">
                      <input
                        className="w-full rounded border border-slate-200 px-2 py-1 no-print"
                        value={item.content}
                        onChange={(e) =>
                          updateChecklistItem(audit.id, item.id, { content: e.target.value })
                        }
                      />
                      <span className="print-only">{item.content}</span>
                      {item.sourceYear && (
                        <span className="mt-1 block text-xs text-amber-700">來源：{item.sourceYear} 年追蹤</span>
                      )}
                    </td>
                    <td className="border p-2 align-top">
                      <select
                        className="w-full rounded border border-slate-200 px-1 py-1 no-print"
                        value={item.judgment ?? ''}
                        onChange={(e) =>
                          updateChecklistItem(audit.id, item.id, {
                            judgment: (e.target.value || null) as Judgment | null,
                          })
                        }
                      >
                        <option value="">—</option>
                        {JUDGMENTS.map((j) => (
                          <option key={j} value={j}>{j}</option>
                        ))}
                      </select>
                      <span className="print-only">{item.judgment && <Badge label={item.judgment} />}</span>
                    </td>
                    <td className="border p-2 align-top">
                      <textarea
                        className="w-full rounded border border-slate-200 px-2 py-1 no-print"
                        rows={2}
                        value={item.description}
                        onChange={(e) =>
                          updateChecklistItem(audit.id, item.id, { description: e.target.value })
                        }
                      />
                      <span className="print-only">{item.description}</span>
                    </td>
                    <td className="border p-2 align-top no-print">
                      <button
                        type="button"
                        className="text-xs text-red-600 hover:underline"
                        onClick={() => removeChecklistItem(audit.id, item.id)}
                      >
                        刪除
                      </button>
                    </td>
                  </tr>
                ))
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
