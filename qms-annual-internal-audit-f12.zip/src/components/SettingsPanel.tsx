import { useRef } from 'react'
import type { AuditStore } from '../hooks/useAuditStore'
import { backupFilename, describeBackup, parseBackupJson } from '../lib/backup'
import { downloadBlob } from '../lib/download'
import { exportAllFormsExcel } from '../lib/formExport'
import { getSeedStats } from '../data/checklistLoader'
import { Button, Card, Input } from './ui/Badge'
import type { CompanyId } from '../types'

export function SettingsPanel({ store }: { store: AuditStore }) {
  const { state, updateSettings, exportJSON, importJSON, resetToDemo, clearAll } = store
  const fileRef = useRef<HTMLInputElement>(null)

  const handleRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const json = reader.result as string
        const preview = parseBackupJson(json)
        const msg = `確定還原備份？\n\n${describeBackup(preview)}\n\n目前資料將被覆寫（localStorage v5）。`
        if (!confirm(msg)) return
        importJSON(json)
        alert('還原成功')
      } catch (err) {
        alert(err instanceof Error ? err.message : '還原失敗：備份格式錯誤')
      }
    }
    reader.readAsText(file)
    e.target.value = ''
  }

  const handleBackup = () => {
    const json = exportJSON()
    downloadBlob(new Blob([json], { type: 'application/json' }), backupFilename(state))
  }

  const handleExportAllExcel = (companyId: CompanyId) => {
    exportAllFormsExcel(state, companyId)
  }

  const seedStats = getSeedStats()

  return (
    <div className="space-y-6">
      <Card>
        <h2 className="mb-2 text-lg font-semibold">查檢表種子（114 年度）</h2>
        <p className="text-sm text-slate-600">
          程序列 {seedStats.procedureEntries} · 唯一 QP {seedStats.qpCoverage}/{seedStats.qpTotal} ·
          系統稽核 {seedStats.systemItems} 項 · 製程 {seedStats.processItems} 項 · 型態 {seedStats.configItems} 項 ·
          稽核重點 {seedStats.focusRows} 列
        </p>
      </Card>

      <Card>
        <h2 className="mb-4 text-lg font-semibold">評分規則設定</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          <Input
            label="符合得分"
            type="number"
            value={state.settings.scoringRules.conform}
            onChange={(v) =>
              updateSettings({
                scoringRules: { ...state.settings.scoringRules, conform: Number(v) },
              })
            }
          />
          <Input
            label="不符得分"
            type="number"
            value={state.settings.scoringRules.nonConform}
            onChange={(v) =>
              updateSettings({
                scoringRules: { ...state.settings.scoringRules, nonConform: Number(v) },
              })
            }
          />
          <Input
            label="觀察得分（部分）"
            type="number"
            step="0.1"
            value={state.settings.scoringRules.observation}
            onChange={(v) =>
              updateSettings({
                scoringRules: { ...state.settings.scoringRules, observation: Number(v) },
              })
            }
          />
        </div>
      </Card>

      <Card>
        <h2 className="mb-4 text-lg font-semibold">資料備份與還原</h2>
        <p className="mb-4 text-sm text-slate-500">
          完整備份含雙公司資料、設定、外部稽核前準備與版本號。儲存於 localStorage key
          <code className="mx-1 rounded bg-slate-100 px-1">qms-annual-internal-audit-v5</code>。
          還原前會確認覆寫；舊版 v4/v1 備份會自動遷移。
        </p>
        <div className="flex flex-wrap gap-3">
          <Button onClick={handleBackup}>備份</Button>
          <Button variant="secondary" onClick={() => fileRef.current?.click()}>
            還原
          </Button>
          <input ref={fileRef} type="file" accept=".json,application/json" className="hidden" onChange={handleRestore} />
          <Button variant="secondary" onClick={() => {
            if (confirm('確定還原為示範資料？')) resetToDemo()
          }}>
            還原示範資料
          </Button>
          <Button variant="danger" onClick={() => {
            if (confirm('確定清除所有資料？此操作無法復原。')) clearAll()
          }}>
            清除全部資料
          </Button>
        </div>
      </Card>

      <Card>
        <h2 className="mb-4 text-lg font-semibold">QR-28 表單匯出（Excel）</h2>
        <p className="mb-4 text-sm text-slate-500">
          一次匯出 QR-28-01 年度計畫、全部 QR-28-02 程序查檢表、QR-28-03 不符合、建議追蹤與稽核前準備（多工作表）。
          各 tab 亦可單獨匯出。
        </p>
        <div className="flex flex-wrap gap-3">
          <Button variant="secondary" onClick={() => handleExportAllExcel('jiurun')}>
            匯出九潤全部表單
          </Button>
          <Button variant="secondary" onClick={() => handleExportAllExcel('zhenglongxing')}>
            匯出正隆興全部表單
          </Button>
          <Button variant="ghost" onClick={() => window.print()}>
            列印目前畫面（PDF）
          </Button>
        </div>
      </Card>

      <Card>
        <h2 className="mb-2 text-lg font-semibold">關於</h2>
        <p className="text-sm text-slate-600">
          QMS 年度內部稽核系統 v2.0 — 程序導向（QP 查檢表）、雙公司切換、
          對應 QR-28-01/02/03/04/05 及 QR-02-01 風險矩陣。
          目前公司：{state.company.name}
        </p>
      </Card>
    </div>
  )
}
