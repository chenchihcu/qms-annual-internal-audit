import { describe, it, expect } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import App from './App'

const TAB_LABELS = [
  '儀表板',
  '年度計畫',
  '程序稽核',
  '不符合',
  '觀察事項',
  '建議追蹤',
  '稽核前準備',
  '風險評估',
  '設定',
]

describe('App tab smoke', () => {
  it('renders all nine tabs without crashing', () => {
    render(<App />)

    for (const label of TAB_LABELS) {
      const tab = screen.getByRole('button', { name: label })
      fireEvent.click(tab)
      expect(screen.queryByText(`${label} 無法顯示`)).toBeNull()
    }
  })

  it('switches company without crashing', () => {
    render(<App />)
    const zlx = screen.getByRole('button', { name: /正隆興精密/ })
    fireEvent.click(zlx)
    expect(screen.getByRole('button', { name: '儀表板' })).toBeTruthy()
  })
})
