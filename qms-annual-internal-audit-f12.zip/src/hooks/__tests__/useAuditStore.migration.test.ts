import { describe, it, expect, beforeEach } from 'vitest'
import { renderHook, act } from '@testing-library/react'
import {
  createDemoState,
  migrateToV5,
  STORAGE_KEY,
} from '../../data/demoData'
import { useAuditStore } from '../useAuditStore'

describe('migrateToV5', () => {
  it('preserves v5 state with externalAuditPrep', () => {
    const demo = createDemoState()
    const migrated = migrateToV5(demo)
    expect(migrated.version).toBe(5)
    expect(migrated.externalAuditPrep).toBeDefined()
    expect(migrated.companies.jiurun.audits.length).toBeGreaterThan(0)
  })

  it('upgrades v4-shaped state to version 5', () => {
    const demo = createDemoState()
    const v4Like = { ...demo, version: 4 as const }
    const migrated = migrateToV5(v4Like)
    expect(migrated.version).toBe(5)
    expect(migrated.externalAuditPrep).toBeDefined()
  })
})

describe('localStorage load parity', () => {
  beforeEach(() => {
    localStorage.clear()
  })

  it('loads v5 key directly', () => {
    const demo = createDemoState()
    localStorage.setItem(STORAGE_KEY, JSON.stringify(demo))

    const { result } = renderHook(() => useAuditStore())
    expect(result.current.state.settings.auditYear).toBe(demo.settings.auditYear)
    expect(result.current.state.company.audits.length).toBeGreaterThan(0)
  })

  it('migrates v4 key to v5 on load', () => {
    const demo = createDemoState()
    const v4Like = { ...demo, version: 4 as const }
    localStorage.setItem('qms-annual-internal-audit-v4', JSON.stringify(v4Like))

    const { result } = renderHook(() => useAuditStore())
    expect(result.current.state.company.audits.length).toBeGreaterThan(0)
    expect(localStorage.getItem(STORAGE_KEY)).toBeTruthy()
  })

  it('falls back to demo when stored JSON is invalid', () => {
    localStorage.setItem(STORAGE_KEY, '{not-json')

    const { result } = renderHook(() => useAuditStore())
    expect(result.current.state.company.audits.length).toBeGreaterThan(0)
  })
})

describe('getOrCreateAudit', () => {
  it('returns stub without throwing when dept and entry are missing', () => {
    const { result } = renderHook(() => useAuditStore())

    let audit: ReturnType<typeof result.current.getOrCreateAudit> | undefined
    expect(() => {
      audit = result.current.getOrCreateAudit('QP-INVALID', 'dept-missing')
    }).not.toThrow()

    expect(audit).toBeDefined()
    expect(audit!.qpCode).toBe('QP-INVALID')
    expect(audit!.items).toEqual([])
  })

  it('creates audit for valid template entry', () => {
    const { result } = renderHook(() => useAuditStore())

    let audit: ReturnType<typeof result.current.getOrCreateAudit> | undefined
    act(() => {
      audit = result.current.getOrCreateAudit('QP-28', 'dept-qa')
    })

    expect(audit).toBeDefined()
    expect(audit!.departmentId).toBe('dept-qa')
    expect(audit!.items.length).toBeGreaterThan(0)
  })
})
