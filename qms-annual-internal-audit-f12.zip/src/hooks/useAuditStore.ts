import { useCallback, useEffect, useMemo, useState } from 'react'
import type {
  AppState,
  AuditSettings,
  ChecklistItem,
  CompanyData,
  CompanyId,
  NCR,
  Observation,
  PlanRow,
  ExternalAuditPrepItemState,
  ProcedureAudit,
  ThirdPartySuggestion,
} from '../types'
import { createDefaultPrepState } from '../lib/externalAuditPrep'
import {
  createDemoState,
  migrateToV4,
  migrateToV5,
  migrateV1State,
  STORAGE_KEY,
} from '../data/demoData'
import { parseBackupJson, serializeBackup } from '../lib/backup'
import { autoArrangePlan } from '../lib/planner'
import { collectNCRsFromAudits, syncNCRDescriptions } from '../lib/ncr'
import { createChecklistForProcedure, getProcedureTitle } from '../data/checklistLoader'
import { PROCEDURE_PLAN_TEMPLATE } from '../data/procedurePlan'
import type { MonthStatus } from '../types'

function loadState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) {
      const parsed = JSON.parse(raw) as AppState
      if (parsed.version >= 5 && parsed.externalAuditPrep) return parsed
      if (parsed.companies) return migrateToV5(parsed)
    }
    const v4 = localStorage.getItem('qms-annual-internal-audit-v4')
    if (v4) {
      const parsed = JSON.parse(v4) as AppState
      if (parsed.companies) return migrateToV5(parsed)
      return migrateToV5(migrateToV4(parsed))
    }
    const legacy = localStorage.getItem('qms-annual-internal-audit-v1')
    if (legacy) {
      const migrated = migrateV1State(JSON.parse(legacy))
      if (migrated) return migrateToV5(migrated)
    }
  } catch {
    /* demo */
  }
  return createDemoState()
}

function saveState(state: AppState) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
}

function patchCompany(
  state: AppState,
  companyId: CompanyId,
  patch: Partial<CompanyData>,
): AppState {
  return {
    ...state,
    companies: {
      ...state.companies,
      [companyId]: { ...state.companies[companyId], ...patch },
    },
  }
}

export function useAuditStore() {
  const [state, setState] = useState<AppState>(loadState)

  useEffect(() => {
    saveState(state)
  }, [state])

  const activeCompany = state.companies[state.activeCompanyId]

  const updateSettings = useCallback((patch: Partial<AuditSettings>) => {
    setState((s) => {
      const settings = { ...s.settings, ...patch }
      let externalAuditPrep = s.externalAuditPrep
      if (patch.auditYear && patch.auditYear !== s.externalAuditPrep.year) {
        externalAuditPrep = createDefaultPrepState(patch.auditYear)
      }
      return { ...s, settings, externalAuditPrep }
    })
  }, [])

  const switchCompany = useCallback((companyId: CompanyId) => {
    setState((s) => ({ ...s, activeCompanyId: companyId }))
  }, [])

  const updateDepartment = useCallback(
    (id: string, patch: Partial<CompanyData['departments'][0]>) => {
      setState((s) => {
        const co = s.companies[s.activeCompanyId]
        return patchCompany(s, s.activeCompanyId, {
          departments: co.departments.map((d) => (d.id === id ? { ...d, ...patch } : d)),
        })
      })
    },
    [],
  )

  const regeneratePlan = useCallback(() => {
    setState((s) => {
      const co = s.companies[s.activeCompanyId]
      const openCount =
        co.observations.filter((o) => o.status === 'open').length +
        co.suggestions.filter((sg) => sg.status === 'open').length +
        co.ncrs.filter((n) => n.status !== '結案').length
      const planRows = autoArrangePlan(
        {
          departments: co.departments,
          planEntries: PROCEDURE_PLAN_TEMPLATE,
          auditYear: s.settings.auditYear,
          planWindowStart: s.settings.planWindowStart,
          planWindowEnd: s.settings.planWindowEnd,
          managementReviewDate: s.settings.managementReviewDate,
          existingRows: co.planRows,
          openCarryForwardCount: openCount,
        },
        { leadAuditor: s.settings.leadAuditor },
      )
      return patchCompany(s, s.activeCompanyId, { planRows })
    })
  }, [])

  const updatePlanRow = useCallback((id: string, patch: Partial<PlanRow>) => {
    setState((s) => {
      const co = s.companies[s.activeCompanyId]
      return patchCompany(s, s.activeCompanyId, {
        planRows: co.planRows.map((r) =>
          r.id === id ? { ...r, ...patch, manualOverride: true } : r,
        ),
      })
    })
  }, [])

  const setPlanMonthStatus = useCallback((rowId: string, monthIndex: number, status: MonthStatus) => {
    setState((s) => {
      const co = s.companies[s.activeCompanyId]
      return patchCompany(s, s.activeCompanyId, {
        planRows: co.planRows.map((r) => {
          if (r.id !== rowId) return r
          const months = [...r.months] as MonthStatus[]
          months[monthIndex] = status
          return { ...r, months, manualOverride: true }
        }),
      })
    })
  }, [])

  const getOrCreateAudit = useCallback(
    (qpCode: string, departmentId: string): ProcedureAudit => {
      const co = activeCompany
      const auditId = `audit-${qpCode}-${departmentId}`
      const existing = co.audits.find((a) => a.id === auditId)
      if (existing) return existing

      const entry =
        PROCEDURE_PLAN_TEMPLATE.find(
          (e) => e.qpCode === qpCode && e.departmentId === departmentId,
        ) ?? PROCEDURE_PLAN_TEMPLATE.find((e) => e.qpCode === qpCode)
      const resolvedDeptId = entry?.departmentId ?? departmentId
      const dept =
        co.departments.find((d) => d.id === departmentId) ??
        co.departments.find((d) => d.id === resolvedDeptId)

      if (!dept || !entry) {
        return {
          id: auditId,
          qpCode,
          departmentId: resolvedDeptId,
          department: dept?.name ?? entry?.departmentName ?? departmentId,
          process: entry?.process ?? qpCode,
          documents: entry?.documents ?? qpCode,
          notifyDate: '',
          auditDate: '',
          departmentManager: dept?.owner ?? '',
          auditors: dept?.defaultAuditors ?? '',
          auditCategory: entry?.auditCategory ?? '系統稽核',
          items: dept ? createChecklistForProcedure(qpCode, dept.name) : [],
        }
      }

      return {
        id: auditId,
        qpCode,
        departmentId: entry.departmentId,
        department: dept.name,
        process: entry.process,
        documents: entry.documents,
        notifyDate: '',
        auditDate: '',
        departmentManager: dept.owner,
        auditors: dept.defaultAuditors,
        auditCategory: entry.auditCategory,
        items: createChecklistForProcedure(qpCode, dept.name),
      }
    },
    [activeCompany],
  )

  const updateAudit = useCallback((audit: ProcedureAudit) => {
    setState((s) => {
      const co = s.companies[s.activeCompanyId]
      const exists = co.audits.some((a) => a.id === audit.id)
      const audits = exists
        ? co.audits.map((a) => (a.id === audit.id ? audit : a))
        : [...co.audits, audit]

      let ncrs = collectNCRsFromAudits(audits, s.settings.auditYear, co.ncrs)
      ncrs = syncNCRDescriptions(ncrs, audits)

      return patchCompany(s, s.activeCompanyId, { audits, ncrs })
    })
  }, [])

  const updateChecklistItem = useCallback(
    (auditId: string, itemId: string, patch: Partial<ChecklistItem>) => {
      setState((s) => {
        const co = s.companies[s.activeCompanyId]
        const audits = co.audits.map((a) => {
          if (a.id !== auditId) return a
          return {
            ...a,
            items: a.items.map((item) =>
              item.id === itemId ? { ...item, ...patch } : item,
            ),
          }
        })
        let ncrs = collectNCRsFromAudits(audits, s.settings.auditYear, co.ncrs)
        ncrs = syncNCRDescriptions(ncrs, audits)
        return patchCompany(s, s.activeCompanyId, { audits, ncrs })
      })
    },
    [],
  )

  const addChecklistItem = useCallback((auditId: string) => {
    setState((s) => {
      const co = s.companies[s.activeCompanyId]
      const audits = co.audits.map((a) => {
        if (a.id !== auditId) return a
        const nextNo = a.items.length + 1
        return {
          ...a,
          items: [
            ...a.items,
            {
              id: `chk-${Date.now()}`,
              category: '自訂',
              no: nextNo,
              content: '',
              judgment: null,
              description: '',
              procedureRef: a.qpCode,
            },
          ],
        }
      })
      return patchCompany(s, s.activeCompanyId, { audits })
    })
  }, [])

  const removeChecklistItem = useCallback((auditId: string, itemId: string) => {
    setState((s) => {
      const co = s.companies[s.activeCompanyId]
      const audits = co.audits.map((a) => {
        if (a.id !== auditId) return a
        const items = a.items
          .filter((i) => i.id !== itemId)
          .map((item, idx) => ({ ...item, no: idx + 1 }))
        return { ...a, items }
      })
      return patchCompany(s, s.activeCompanyId, { audits })
    })
  }, [])

  const updateNCR = useCallback((id: string, patch: Partial<NCR>) => {
    setState((s) => {
      const co = s.companies[s.activeCompanyId]
      return patchCompany(s, s.activeCompanyId, {
        ncrs: co.ncrs.map((n) => (n.id === id ? { ...n, ...patch } : n)),
      })
    })
  }, [])

  const updateObservation = useCallback((id: string, patch: Partial<Observation>) => {
    setState((s) => {
      const co = s.companies[s.activeCompanyId]
      return patchCompany(s, s.activeCompanyId, {
        observations: co.observations.map((o) => (o.id === id ? { ...o, ...patch } : o)),
      })
    })
  }, [])

  const updateSuggestion = useCallback((id: string, patch: Partial<ThirdPartySuggestion>) => {
    setState((s) => {
      const co = s.companies[s.activeCompanyId]
      return patchCompany(s, s.activeCompanyId, {
        suggestions: co.suggestions.map((sg) => (sg.id === id ? { ...sg, ...patch } : sg)),
      })
    })
  }, [])

  const updateExternalPrepItem = useCallback(
    (id: string, patch: Partial<ExternalAuditPrepItemState>) => {
      setState((s) => ({
        ...s,
        externalAuditPrep: {
          ...s.externalAuditPrep,
          items: s.externalAuditPrep.items.map((p) =>
            p.id === id ? { ...p, ...patch } : p,
          ),
        },
      }))
    },
    [],
  )

  const updateExternalPrepSequence = useCallback(
    (patch: Partial<Pick<AppState['externalAuditPrep'], 'internalAuditComplete' | 'managementReviewComplete'>>) => {
      setState((s) => ({
        ...s,
        externalAuditPrep: { ...s.externalAuditPrep, ...patch },
      }))
    },
    [],
  )

  const carryForwardObservation = useCallback(
    (obsId: string, qpCode: string, departmentId: string) => {
      setState((s) => {
        const co = s.companies[s.activeCompanyId]
        const obs = co.observations.find((o) => o.id === obsId)
        if (!obs) return s

        const auditId = `audit-${qpCode}-${departmentId}`
        let audit = co.audits.find((a) => a.id === auditId)
        const dept = co.departments.find((d) => d.id === departmentId)
        const entry = PROCEDURE_PLAN_TEMPLATE.find(
          (e) => e.qpCode === qpCode && e.departmentId === departmentId,
        )
        if (!dept || !entry) return s

        if (!audit) {
          audit = {
            id: auditId,
            qpCode,
            departmentId,
            department: dept.name,
            process: entry.process,
            documents: entry.documents,
            notifyDate: '',
            auditDate: '',
            departmentManager: dept.owner,
            auditors: dept.defaultAuditors,
            auditCategory: entry.auditCategory,
            items: createChecklistForProcedure(qpCode, dept.name),
          }
        }

        const newItemId = `chk-cf-${Date.now()}`
        const newItem: ChecklistItem = {
          id: newItemId,
          category: '跨年追蹤',
          no: audit.items.length + 1,
          content: `[${obs.year}年觀察事項] ${obs.content}`,
          judgment: null,
          description: obs.description,
          sourceYear: obs.year,
          carriedFromId: obs.id,
          procedureRef: qpCode,
        }

        const audits = co.audits.some((a) => a.id === audit!.id)
          ? co.audits.map((a) =>
              a.id === audit!.id ? { ...a, items: [...a.items, newItem] } : a,
            )
          : [...co.audits, { ...audit, items: [...audit.items, newItem] }]

        const observations = co.observations.map((o) =>
          o.id === obsId
            ? { ...o, carriedToYear: s.settings.auditYear, carriedToChecklistId: newItemId }
            : o,
        )

        return patchCompany(s, s.activeCompanyId, { audits, observations })
      })
    },
    [],
  )

  const carryForwardNCR = useCallback((ncrId: string, qpCode: string, departmentId: string) => {
    setState((s) => {
      const co = s.companies[s.activeCompanyId]
      const ncr = co.ncrs.find((n) => n.id === ncrId)
      if (!ncr || ncr.status === '結案') return s

      const auditId = `audit-${qpCode}-${departmentId}`
      let audit = co.audits.find((a) => a.id === auditId)
      const dept = co.departments.find((d) => d.id === departmentId)
      const entry = PROCEDURE_PLAN_TEMPLATE.find(
        (e) => e.qpCode === qpCode && e.departmentId === departmentId,
      ) ?? PROCEDURE_PLAN_TEMPLATE.find((e) => e.qpCode === qpCode)
      if (!dept || !entry) return s

      if (!audit) {
        audit = {
          id: auditId,
          qpCode,
          departmentId,
          department: dept.name,
          process: entry.process,
          documents: entry.documents,
          notifyDate: '',
          auditDate: '',
          departmentManager: dept.owner,
          auditors: dept.defaultAuditors,
          auditCategory: entry.auditCategory,
          items: createChecklistForProcedure(qpCode, dept.name),
        }
      }

      const newItemId = `chk-ncr-cf-${Date.now()}`
      const year = ncr.sourceYear ?? s.settings.auditYear - 1
      const newItem: ChecklistItem = {
        id: newItemId,
        category: '跨年追蹤',
        no: audit.items.length + 1,
        content: `[${year}年 NCR ${ncr.ncrNumber}] ${ncr.description}`,
        judgment: null,
        description: '前年度未結案不符合追蹤',
        sourceYear: year,
        procedureRef: qpCode,
      }

      const audits = co.audits.some((a) => a.id === audit!.id)
        ? co.audits.map((a) =>
            a.id === audit!.id ? { ...a, items: [...a.items, newItem] } : a,
          )
        : [...co.audits, { ...audit, items: [...audit.items, newItem] }]

      return patchCompany(s, s.activeCompanyId, { audits })
    })
  }, [])

  const carryForwardSuggestion = useCallback(
    (sugId: string, qpCode: string, departmentId: string) => {
      setState((s) => {
        const co = s.companies[s.activeCompanyId]
        const sug = co.suggestions.find((sg) => sg.id === sugId)
        if (!sug || sug.status === 'closed') return s

        const auditId = `audit-${qpCode}-${departmentId}`
        let audit = co.audits.find((a) => a.id === auditId)
        const dept = co.departments.find((d) => d.id === departmentId)
        const entry = PROCEDURE_PLAN_TEMPLATE.find(
          (e) => e.qpCode === qpCode && e.departmentId === departmentId,
        )
        if (!dept || !entry) return s

        if (!audit) {
          audit = {
            id: auditId,
            qpCode,
            departmentId,
            department: dept.name,
            process: entry.process,
            documents: entry.documents,
            notifyDate: '',
            auditDate: '',
            departmentManager: dept.owner,
            auditors: dept.defaultAuditors,
            auditCategory: entry.auditCategory,
            items: createChecklistForProcedure(qpCode, dept.name),
          }
        }

        const newItemId = `chk-sug-cf-${Date.now()}`
        const newItem: ChecklistItem = {
          id: newItemId,
          category: '第三方建議',
          no: audit.items.length + 1,
          content: `[${sug.year}年第三方建議] ${sug.issue}`,
          judgment: null,
          description: sug.progress,
          sourceYear: sug.year,
          procedureRef: qpCode,
        }

        const audits = co.audits.some((a) => a.id === audit!.id)
          ? co.audits.map((a) =>
              a.id === audit!.id ? { ...a, items: [...a.items, newItem] } : a,
            )
          : [...co.audits, { ...audit, items: [...audit.items, newItem] }]

        const suggestions = co.suggestions.map((sg) =>
          sg.id === sugId ? { ...sg, carriedToYear: s.settings.auditYear } : sg,
        )

        return patchCompany(s, s.activeCompanyId, { audits, suggestions })
      })
    },
    [],
  )

  const exportJSON = useCallback(() => serializeBackup(state), [state])

  const importJSON = useCallback((json: string) => {
    const migrated = parseBackupJson(json)
    setState(migrated)
  }, [])

  const resetToDemo = useCallback(() => setState(createDemoState()), [])

  const clearAll = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY)
    localStorage.removeItem('qms-annual-internal-audit-v4')
    localStorage.removeItem('qms-annual-internal-audit-v1')
    setState(createDemoState())
  }, [])

  const ensureAllAudits = useCallback(() => {
    setState((s) => {
      const co = s.companies[s.activeCompanyId]
      const audits = [...co.audits]
      for (const entry of PROCEDURE_PLAN_TEMPLATE) {
        const id = `audit-${entry.qpCode}-${entry.departmentId}`
        if (!audits.some((a) => a.id === id)) {
          const dept = co.departments.find((d) => d.id === entry.departmentId)
          if (!dept) continue
          audits.push({
            id,
            qpCode: entry.qpCode,
            departmentId: entry.departmentId,
            department: dept.name,
            process: entry.process,
            documents: entry.documents,
            notifyDate: '',
            auditDate: '',
            departmentManager: dept.owner,
            auditors: dept.defaultAuditors,
            auditCategory: entry.auditCategory,
            items: createChecklistForProcedure(entry.qpCode, dept.name),
          })
        }
      }
      return patchCompany(s, s.activeCompanyId, { audits })
    })
  }, [])

  const syncedState = useMemo(
    () => ({
      ...state,
      company: activeCompany,
    }),
    [state, activeCompany],
  )

  return {
    state: syncedState,
    updateSettings,
    switchCompany,
    updateDepartment,
    regeneratePlan,
    updatePlanRow,
    setPlanMonthStatus,
    getOrCreateAudit,
    updateAudit,
    updateChecklistItem,
    addChecklistItem,
    removeChecklistItem,
    updateNCR,
    updateObservation,
    updateSuggestion,
    updateExternalPrepItem,
    updateExternalPrepSequence,
    carryForwardObservation,
    carryForwardNCR,
    carryForwardSuggestion,
    exportJSON,
    importJSON,
    resetToDemo,
    clearAll,
    ensureAllAudits,
    getProcedureTitle,
  }
}

export type AuditStore = ReturnType<typeof useAuditStore>
