# Production Release Checklist

Release target: commit `be3b8ba` (validation layer + browser smoke confirmed)

## Gate 1 — Artifact Verification

| Check | Result | Evidence |
|-------|--------|----------|
| `npm run lint` | PASS | oxlint 0 errors |
| `npm test` | PASS | 7 files / 39 tests |
| `npm run build` | PASS | dist/ produced |
| `npm audit --audit-level=high` | PASS | 0 vulnerabilities |

## Gate 2 — Environment Parity

| Check | Result | Evidence |
|-------|--------|----------|
| v5 key load | PASS | `useAuditStore.migration.test.ts` |
| v4 → v5 migrate | PASS | `useAuditStore.migration.test.ts` |
| Invalid JSON fallback | PASS | `useAuditStore.migration.test.ts` |
| `getOrCreateAudit` no-throw stub | PASS | `useAuditStore.migration.test.ts` |

## Gate 3 — Smoke & Sanity

| Check | Result | Evidence |
|-------|--------|----------|
| Dev server (43123) nine tabs | PASS | [Browser smoke test](bc-d9f999d0-71db-5a75-97a2-36247af4f55e) + `App.smoke.test.tsx` |
| Company switch | PASS | [Browser smoke test](bc-d9f999d0-71db-5a75-97a2-36247af4f55e) |
| Hard refresh persistence | PASS | [Browser smoke test](bc-d9f999d0-71db-5a75-97a2-36247af4f55e) |
| Preview bundle (43124) core tabs | PASS | [Browser smoke test](bc-d9f999d0-71db-5a75-97a2-36247af4f55e) |

**Known non-blocker:** React `title` prop warnings when month status is non-string — patched in `AnnualPlan.tsx`.

## Gate 4 — Rollback Preparedness

| Layer | Action |
|-------|--------|
| Code | `git revert` or checkout pre-fix commit |
| User data | Settings → Export JSON; v4 key retained until v5 write |
| Emergency | zip workspace (exclude node_modules, .git, dist) + SHA256 |

## User Upgrade Steps

1. `git pull`
2. Export JSON backup (Settings tab)
3. `npm install && npm test && npm run dev`
4. If white screen: Settings → Clear all data
