# QMS 年度內部稽核系統

114 年度內部稽核查檢表完整種子（九潤精密／正隆興精密），對應 QR-28 系列紙本表單設計。

## 快速開始

```bash
npm install
npm run dev    # http://127.0.0.1:43123
npm test       # 46 項單元／回歸／smoke 測試
npm run build  # production bundle → dist/
npm run preview -- --port 43124 --host 127.0.0.1
```

## 升級與資料遷移（v5）

1. `git pull` 取得最新版（含 crash-safe 修復與 v5 storage）
2. 建議先在「設定」tab **備份** 現有資料（完整 AppState JSON）
3. localStorage key：`qms-annual-internal-audit-v5`（會自動自 v4 / v1 遷移）
4. 若仍白屏：設定 → **清除全部資料**，或 DevTools 刪除舊 key 後重新整理
5. 驗證：`npm test` 全過、`npm run dev` 後九個 tab 皆可瀏覽

## 查檢表種子覆蓋率（SEED_JSON 6/6）

| 指標 | 數值 |
|------|------|
| 程序列（raw entries） | **29**（QP-16 業務/品保各一） |
| 唯一 QP 代碼 | **28/28（100%）** |
| 系統稽核查檢項 | **130** |
| 製程稽核 QR-28-04 | **18** |
| 型態稽核 QR-28-05 | **4** |
| 合計查檢項 | **152** |
| 稽核重點標示列 | **27** + 製程/型態 |

補充程序：**QP-09**（紀錄文件）、**QP-13**（風險作業）依 seed 標記 `supplemented`。

## 採用的紙本設計優點

1. **程序導向** — 以 QP 查檢表為主；QP-16 業務部/品保部獨立項目  
2. **QR-28-02 表頭** — 被稽核部門、稽核流程、對應文件、日期、主管、稽核人員  
3. **列格式** — 項目｜NO｜稽核內容｜判定｜內容說明  
4. **稽核重點標示** — 儀表板 focusLegend（風險、單位、負責人、項數）  
5. **月格計畫** — 擬定/滿意/不滿意/矯正中/矯正圓滿  
6. **雙公司** — 九潤精密｜正隆興精密  
7. **三類稽核** — 系統｜製程(QR-28-04)｜型態(QR-28-05)  
8. **跨年度** — NCR/觀察/第三方建議帶入新年度  
9. **建議追蹤** — open/closed 一覽表  
10. **稽核前準備** — 雙公司合併取證外部稽核前查核表（一張證書、兩家公司）  
11. **列印 CSS** — QR-28 表單邊框版型  

## 外部稽核前準備（dual_company_single_certificate）

- 種子：`src/data/externalAuditPrep.seed.json`  
- 來源：**第三方主任稽核員長期觀察 — 九潤+正隆興合併稽核取得一張證書**（措辭 verbatim，不自行改寫）  
- 欄位：項次｜稽核前準備事項｜負責人｜九潤｜正隆興｜完成｜備註/表單  
- 範圍模式：`both_separate`（◎◎）、`merged`（合併）、`site_scope`（稽核廠區範圍）  
- 序位橫幅：內部稽核完成 → 管理審查完成 → 外部稽核；未結 NCR / 管審順序錯誤時警告  
- 狀態依年度共用，儲存於 AppState `externalAuditPrep`（非 per-company）

## 資料

- 查檢表種子：`src/data/checklists.seed.json`（`import.finalized: true`）  
- localStorage：`qms-annual-internal-audit-v5`（自動自 v4 遷移）  

## 備份與還原

- **設定 → 備份**：下載含雙公司、設定、`externalAuditPrep`、版本號的 JSON（`QMS備份_YYYY-MM-DD.json`）
- **設定 → 還原**：選擇備份檔，確認覆寫後寫入 localStorage v5；v4/v1 舊檔會自動遷移
- 還原前建議先備份；失敗時不會覆寫（需通過結構驗證）

## QR-28 表單匯出

| 表單 | 位置 | 格式 |
|------|------|------|
| QR-28-01 年度計畫 | 年度計畫 tab / 設定 | Excel、HTML（Word 可開） |
| QR-28-02 程序查檢表 | 程序稽核 tab / 設定 | Excel（目前／全部）、HTML |
| QR-28-03 不符合 | 不符合 tab / 設定 | Excel |
| 建議追蹤、稽核前準備 | 設定「匯出全部表單」 | Excel 工作表 |

瀏覽器端產生（SheetJS）；欄位對齊現有 UI／紙本表頭。列印 PDF 可用各 tab「列印」或瀏覽器「另存 PDF」。

## 後續路線圖（3–8）

3. Excel 查檢表 re-import／版本更新  
4. 查檢項／NCR 證據附件（IndexedDB 或 base64，大小上限）  
5. 稽核前準備依計畫／NCR／稽核進度自動勾選  
6. 外部稽核當日行程＋受稽產品／型號  
7. 多角色檢視（主任稽核員 vs 部門）  
8. AS9100 條款對照映射  

## 技術棧

Vite + React + TypeScript + Tailwind CSS v4 + Vitest
