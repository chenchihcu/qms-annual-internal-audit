# QMS 年度內部稽核 — Agent 行為規則（harvested）

> 自 crash 修復與 production release validation 互動萃取。僅 stability／資料一致性，非功能擴充。

## Demo 與 Seed 對齊

- [ ] `createDemoState` / `buildAudit` 的 `qpCode` + `departmentId` 必須存在於 `PROCEDURE_PLAN_TEMPLATE`
- [ ] 變更 demo 配對時同步更新 `demoData.smoke.test.ts` 的 `DEMO_AUDIT_PAIRS`
- [ ] `buildAudit` throw 僅允許 seed 錯配時在 **demo 建置路徑**；runtime 用 `getOrCreateAudit` stub，不可 throw

## localStorage 與遷移

- [ ] 現行 key：`qms-annual-internal-audit-v5`（`STORAGE_KEY`）
- [ ] `loadState` 順序：v5 → v4 migrate → v1 migrate → demo fallback；JSON parse 失敗不得 crash
- [ ]  bump storage 時：實作 `migrateToV*`，加 migration test，README 註明升級步驟

## Crash-Safe UI

- [ ] 九個 tab 皆包 `TabErrorBoundary`；class 須在 `App()` 之前定義（避免 ReferenceError 白屏）
- [ ] `AnnualPlan.statusShort`：null-safe（`status == null` → `''`）
- [ ] `emptyMonths`：`Array.from({ length: 12 }, () => null)`，勿用 sparse array
- [ ] `getOrCreateAudit`：缺 dept/entry 回傳 stub（`items: []`），不 throw
- [ ] `ensureAllAudits`：缺 dept 時 `continue`，不 throw

## Release Gate（local-first SPA）

- [ ] `npm run lint && npm test && npm run build` 全過才交付
- [ ] dev（43123）+ preview（43124）至少 smoke：儀表板、年度計畫、程序稽核、設定
- [ ] 變更後跑 `demoData.smoke.test.ts`、`useAuditStore.migration.test.ts`、`App.smoke.test.tsx`

## 交付約束

- [ ] stability fixes only；未要求不開 PR、不改 product features
- [ ] 緊急 zip：排除 `node_modules`、`.git`、`dist`；附 SHA256
- [ ] README 測試數與 `npm test` 實際數量一致
