import { calculateAnnualScore } from '../lib/scoring'
import { buildAuditFocusOverview } from '../lib/planner'
import type { AppState } from '../types'
import { Badge, Card } from './ui/Badge'

interface DashboardProps {
  state: AppState & { company: AppState['companies'][keyof AppState['companies']] }
}

export function Dashboard({ state }: DashboardProps) {
  const { company, settings } = state
  const summary = calculateAnnualScore(company.audits, settings.scoringRules)
  const focusRows = buildAuditFocusOverview(company.planRows)
  const openNCR = company.ncrs.filter((n) => n.status !== '結案').length
  const openObs = company.observations.filter((o) => o.status === 'open').length
  const openSug = company.suggestions.filter((s) => s.status === 'open').length
  const plannedMonths = company.planRows.reduce(
    (sum, r) => sum + r.months.filter(Boolean).length,
    0,
  )

  const byCategory = {
    系統稽核: company.planRows.filter((r) => r.auditCategory === '系統稽核').length,
    製程稽核: company.planRows.filter((r) => r.auditCategory === '製程稽核').length,
    型態稽核: company.planRows.filter((r) => r.auditCategory === '型態稽核').length,
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <p className="text-sm text-slate-500">年度總分 · {company.name}</p>
          <p className="mt-1 text-3xl font-bold text-blue-700">{summary.overallScore}%</p>
          <div className="mt-2 h-2 rounded-full bg-slate-100">
            <div
              className="h-2 rounded-full bg-blue-600 transition-all"
              style={{ width: `${Math.min(summary.overallScore, 100)}%` }}
            />
          </div>
        </Card>
        <Card>
          <p className="text-sm text-slate-500">不符合（NCR）</p>
          <p className="mt-1 text-3xl font-bold text-red-600">{company.ncrs.length}</p>
          <p className="mt-1 text-xs text-slate-500">未結案 {openNCR} 件</p>
        </Card>
        <Card>
          <p className="text-sm text-slate-500">觀察 / 第三方建議</p>
          <p className="mt-1 text-3xl font-bold text-amber-600">{summary.totalObservation + openSug}</p>
          <p className="mt-1 text-xs text-slate-500">待追蹤 {openObs + openSug} 件</p>
        </Card>
        <Card>
          <p className="text-sm text-slate-500">計畫稽核次數</p>
          <p className="mt-1 text-3xl font-bold text-slate-800">{plannedMonths}</p>
          <p className="text-xs text-slate-500">
            系統 {byCategory.系統稽核} · 製程 {byCategory.製程稽核} · 型態 {byCategory.型態稽核}
          </p>
        </Card>
      </div>

      <Card>
        <h2 className="mb-4 text-lg font-semibold">稽核重點標示（QR-28-01 概覽）</h2>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="border-b bg-slate-50 text-left text-slate-600">
                <th className="p-2">Sheet</th>
                <th className="p-2">風險等級</th>
                <th className="p-2">稽核程序</th>
                <th className="p-2">被稽核單位</th>
                <th className="p-2">負責人</th>
                <th className="p-2 text-center">查檢項數</th>
                <th className="p-2">稽核類型</th>
              </tr>
            </thead>
            <tbody>
              {focusRows.map((row) => (
                <tr key={`${row.sheet}-${row.qpCode}-${row.department}`} className="border-b border-slate-100">
                  <td className="p-2 text-slate-500">{row.sheet}</td>
                  <td className="p-2"><Badge label={row.riskLevel} /></td>
                  <td className="p-2 font-medium">{row.qpCode}</td>
                  <td className="p-2">{row.department}</td>
                  <td className="p-2">{row.owner}</td>
                  <td className="p-2 text-center">{row.itemCount}</td>
                  <td className="p-2 text-slate-600">{row.auditCategory}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card>
        <h2 className="mb-4 text-lg font-semibold">各程序稽核得分</h2>
        <div className="space-y-3">
          {summary.departmentScores.length === 0 ? (
            <p className="text-sm text-slate-500">尚無稽核資料，請至「程序稽核」填寫查檢表。</p>
          ) : (
            summary.departmentScores.map((d) => (
              <div key={d.auditId} className="flex items-center gap-3">
                <span className="w-40 shrink-0 text-sm font-medium">{d.label}</span>
                <div className="flex-1">
                  <div className="h-3 rounded-full bg-slate-100">
                    <div
                      className={`h-3 rounded-full ${d.score >= 80 ? 'bg-green-500' : d.score >= 60 ? 'bg-amber-500' : 'bg-red-500'}`}
                      style={{ width: `${Math.min(d.score, 100)}%` }}
                    />
                  </div>
                </div>
                <span className="w-14 text-right text-sm font-semibold">{d.score}%</span>
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  )
}
