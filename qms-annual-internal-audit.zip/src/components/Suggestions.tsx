import type { AuditStore } from '../hooks/useAuditStore'
import type { SuggestionStatus } from '../types'
import { Badge, Button, Card, Select } from './ui/Badge'

export function Suggestions({ store }: { store: AuditStore }) {
  const { state, updateSuggestion, carryForwardSuggestion } = store
  const { company, settings } = state
  const currentYear = settings.auditYear

  const statusLabel: Record<SuggestionStatus, string> = {
    open: '待追蹤',
    closed: '已結案',
  }

  const prior = company.suggestions.filter((s) => s.year < currentYear)
  const current = company.suggestions.filter((s) => s.year >= currentYear)

  return (
    <div className="space-y-6 print-area">
      <Card>
        <h2 className="mb-2 text-lg font-semibold">第三方稽核建議事項一覽表</h2>
        <p className="mb-4 text-sm text-slate-500">
          對應紙本建議追蹤表：程序、問題、進度、負責單位；可帶入新年度查檢表。
        </p>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 text-left">
                <th className="border p-2">年度</th>
                <th className="border p-2">程序</th>
                <th className="border p-2">問題描述</th>
                <th className="border p-2">進度</th>
                <th className="border p-2">負責單位</th>
                <th className="border p-2">狀態</th>
                <th className="border p-2 no-print">操作</th>
              </tr>
            </thead>
            <tbody>
              {[...prior, ...current].map((sug) => (
                <tr key={sug.id} className={sug.status === 'open' ? 'bg-amber-50/30' : ''}>
                  <td className="border p-2">{sug.year}</td>
                  <td className="border p-2 font-medium">{sug.procedure}</td>
                  <td className="border p-2">{sug.issue}</td>
                  <td className="border p-2">
                    <textarea
                      className="w-full min-w-[160px] rounded border border-slate-200 px-2 py-1 no-print"
                      rows={2}
                      value={sug.progress}
                      onChange={(e) => updateSuggestion(sug.id, { progress: e.target.value })}
                    />
                    <span className="print-only">{sug.progress}</span>
                  </td>
                  <td className="border p-2">{sug.responsibleUnit}</td>
                  <td className="border p-2">
                    <div className="no-print">
                      <Select
                        value={sug.status}
                        onChange={(v) => updateSuggestion(sug.id, { status: v as SuggestionStatus })}
                        options={[
                          { value: 'open', label: '待追蹤' },
                          { value: 'closed', label: '已結案' },
                        ]}
                      />
                    </div>
                    <span className="print-only"><Badge label={statusLabel[sug.status]} /></span>
                  </td>
                  <td className="border p-2 no-print">
                    {sug.status === 'open' && !sug.carriedToYear && (
                      <Button
                        variant="secondary"
                        onClick={() => {
                          const row = company.planRows.find((r) => r.qpCode === sug.procedure)
                          if (row) {
                            carryForwardSuggestion(sug.id, row.qpCode, row.departmentId)
                          }
                        }}
                      >
                        帶入 {currentYear} 年
                      </Button>
                    )}
                    {sug.carriedToYear && (
                      <span className="text-xs text-blue-600">已帶入 {sug.carriedToYear}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
