import { useEffect, useState } from 'react'
import type { AuditStore } from '../hooks/useAuditStore'
import { scoreDepartmentAudit } from '../lib/scoring'
import type { Judgment } from '../types'
import { Badge, Button, Card, Input, Select } from './ui/Badge'

const JUDGMENTS: Judgment[] = ['符合', '不符', '觀察', '不適用']

export function DepartmentAuditPanel({ store }: { store: AuditStore }) {
  const {
    state,
    getOrCreateAudit,
    updateAudit,
    updateChecklistItem,
    addChecklistItem,
    removeChecklistItem,
    ensureAllAudits,
  } = store

  const [selectedDeptId, setSelectedDeptId] = useState(state.departments[0]?.id ?? '')

  useEffect(() => {
    ensureAllAudits()
  }, [ensureAllAudits])

  const audit = state.audits.find((a) => a.departmentId === selectedDeptId)
    ?? (selectedDeptId ? getOrCreateAudit(selectedDeptId) : null)

  if (!audit) {
    return <p className="text-slate-500">請先設定部門資料</p>
  }

  const score = scoreDepartmentAudit(audit, state.settings.scoringRules)

  const handleHeaderChange = (field: string, value: string) => {
    updateAudit({ ...audit, [field]: value })
  }

  return (
    <div className="space-y-6 print-area">
      <Card>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-4 no-print">
          <h2 className="text-lg font-semibold">內部稽核查檢表（QR-28-02）</h2>
          <Select
            label=""
            value={selectedDeptId}
            onChange={setSelectedDeptId}
            options={state.departments.map((d) => ({ value: d.id, label: d.name }))}
          />
        </div>

        <div className="print-only mb-4 text-center">
          <h1 className="text-xl font-bold">{state.settings.companyName}</h1>
          <p>內部稽核查檢表 · {audit.department}</p>
        </div>

        <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Input label="被稽核部門" value={audit.department} onChange={() => {}} className="opacity-70" />
          <Input label="稽核流程" value={audit.process} onChange={(v) => handleHeaderChange('process', v)} />
          <Input label="對應文件" value={audit.documents} onChange={(v) => handleHeaderChange('documents', v)} />
          <Input label="通知日期" type="date" value={audit.notifyDate} onChange={(v) => handleHeaderChange('notifyDate', v)} />
          <Input label="實施日期" type="date" value={audit.auditDate} onChange={(v) => handleHeaderChange('auditDate', v)} />
          <Input label="被稽核部門主管" value={audit.departmentManager} onChange={(v) => handleHeaderChange('departmentManager', v)} />
          <Input label="稽核人員" value={audit.auditors} onChange={(v) => handleHeaderChange('auditors', v)} />
        </div>

        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm">部門得分：<span className="text-lg font-bold text-blue-700">{score.score}%</span></p>
          <Button variant="secondary" className="no-print" onClick={() => addChecklistItem(audit.id)}>
            新增稽核項目
          </Button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 text-left">
                <th className="border p-2 w-12">NO</th>
                <th className="border p-2">稽核內容</th>
                <th className="border p-2 w-28">判定</th>
                <th className="border p-2">內容說明</th>
                <th className="border p-2 w-20 no-print">操作</th>
              </tr>
            </thead>
            <tbody>
              {audit.items.map((item) => (
                <tr key={item.id} className={item.sourceYear ? 'bg-amber-50/40' : ''}>
                  <td className="border p-2 align-top">{item.no}</td>
                  <td className="border p-2 align-top">
                    <input
                      className="w-full rounded border border-slate-200 px-2 py-1 no-print"
                      value={item.content}
                      onChange={(e) =>
                        updateChecklistItem(audit.id, item.id, { content: e.target.value })
                      }
                    />
                    <span className="print-only">{item.content}</span>
                    {item.procedureRef && (
                      <span className="mt-1 block text-xs text-slate-500">{item.procedureRef}</span>
                    )}
                    {item.sourceYear && (
                      <span className="mt-1 block text-xs text-amber-700">來源：{item.sourceYear} 年觀察事項</span>
                    )}
                  </td>
                  <td className="border p-2 align-top">
                    <select
                      className="w-full rounded border border-slate-200 px-1 py-1 no-print"
                      value={item.judgment ?? ''}
                      onChange={(e) =>
                        updateChecklistItem(audit.id, item.id, {
                          judgment: (e.target.value || null) as Judgment | null,
                        })
                      }
                    >
                      <option value="">—</option>
                      {JUDGMENTS.map((j) => (
                        <option key={j} value={j}>{j}</option>
                      ))}
                    </select>
                    <span className="print-only">{item.judgment && <Badge label={item.judgment} />}</span>
                  </td>
                  <td className="border p-2 align-top">
                    <textarea
                      className="w-full rounded border border-slate-200 px-2 py-1 no-print"
                      rows={2}
                      value={item.description}
                      onChange={(e) =>
                        updateChecklistItem(audit.id, item.id, { description: e.target.value })
                      }
                    />
                    <span className="print-only">{item.description}</span>
                  </td>
                  <td className="border p-2 align-top no-print">
                    <button
                      type="button"
                      className="text-xs text-red-600 hover:underline"
                      onClick={() => removeChecklistItem(audit.id, item.id)}
                    >
                      刪除
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
