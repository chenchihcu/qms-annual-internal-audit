import type { AuditStore } from '../hooks/useAuditStore'
import type { ObservationStatus } from '../types'
import { Badge, Button, Card, Select } from './ui/Badge'

export function Observations({ store }: { store: AuditStore }) {
  const {
    state,
    updateObservation,
    carryForwardObservation,
    carryForwardNCR,
    regeneratePlan,
  } = store
  const { company, settings } = state
  const currentYear = settings.auditYear
  const priorObs = company.observations.filter((o) => o.year < currentYear)
  const openPriorNCR = company.ncrs.filter((n) => n.status !== '結案')

  const auditObservations = company.audits.flatMap((audit) =>
    audit.items
      .filter((item) => item.judgment === '觀察')
      .map((item) => ({
        id: item.id,
        label: `${audit.qpCode} · ${audit.department}`,
        content: item.content,
        description: item.description,
        sourceYear: item.sourceYear,
      })),
  )

  const statusLabel: Record<ObservationStatus, string> = {
    open: '待追蹤',
    closed: '已結案',
    became_ncr: '已轉 NCR',
  }

  const importAllOpen = () => {
    for (const obs of priorObs.filter((o) => o.status === 'open' && !o.carriedToYear)) {
      const qp = obs.qpCode || 'QP-01'
      carryForwardObservation(obs.id, qp, obs.departmentId)
    }
    for (const ncr of openPriorNCR) {
      carryForwardNCR(ncr.id, ncr.qpCode, ncr.departmentId)
    }
    regeneratePlan()
  }

  return (
    <div className="space-y-6">
      <Card className="no-print">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold">跨年度追蹤匯入</h2>
            <p className="text-sm text-slate-500">
              一鍵帶入前年度 open 觀察事項、未結案 NCR，並重新編排計畫（提高風險權重）。
            </p>
          </div>
          <Button onClick={importAllOpen}>匯入全部待追蹤項目</Button>
        </div>
      </Card>

      <Card>
        <h2 className="mb-2 text-lg font-semibold">跨年觀察事項追蹤</h2>
        <h3 className="mb-3 font-medium">前年度觀察事項（{priorObs.length}）</h3>
        {priorObs.length === 0 ? (
          <p className="text-sm text-slate-500">無前年度觀察事項</p>
        ) : (
          <div className="space-y-3">
            {priorObs.map((obs) => (
              <div key={obs.id} className="rounded-lg border border-slate-200 p-4">
                <div className="mb-2 flex flex-wrap items-center gap-2">
                  <Badge label={`${obs.year}年`} />
                  <span className="font-medium">{obs.qpCode} · {obs.department}</span>
                  <Badge label={statusLabel[obs.status]} />
                  {obs.carriedToYear && (
                    <span className="text-xs text-blue-600">已帶入 {obs.carriedToYear} 年</span>
                  )}
                </div>
                <p className="text-sm">{obs.content}</p>
                <p className="mt-1 text-xs text-slate-500">{obs.description}</p>
                <div className="mt-3 flex flex-wrap gap-2 no-print">
                  {!obs.carriedToYear && (
                    <Button
                      variant="secondary"
                      onClick={() =>
                        carryForwardObservation(obs.id, obs.qpCode, obs.departmentId)
                      }
                    >
                      帶入 {currentYear} 年查檢表
                    </Button>
                  )}
                  <Select
                    value={obs.status}
                    onChange={(v) => updateObservation(obs.id, { status: v as ObservationStatus })}
                    options={[
                      { value: 'open', label: '待追蹤' },
                      { value: 'closed', label: '已結案' },
                      { value: 'became_ncr', label: '已轉 NCR' },
                    ]}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card>
        <h3 className="mb-3 font-medium">未結案 NCR 跨年追蹤（{openPriorNCR.length}）</h3>
        {openPriorNCR.length === 0 ? (
          <p className="text-sm text-slate-500">無未結案 NCR</p>
        ) : (
          <ul className="space-y-2 text-sm">
            {openPriorNCR.map((ncr) => (
              <li key={ncr.id} className="flex flex-wrap items-center justify-between gap-2 rounded border p-3">
                <span>{ncr.ncrNumber} · {ncr.qpCode} · {ncr.description}</span>
                <Button
                  variant="secondary"
                  onClick={() => carryForwardNCR(ncr.id, ncr.qpCode, ncr.departmentId)}
                >
                  帶入查檢表
                </Button>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card>
        <h3 className="mb-3 font-medium">{currentYear} 年度觀察事項（來自查檢表）</h3>
        {auditObservations.length === 0 ? (
          <p className="text-sm text-slate-500">查檢表判定「觀察」後會顯示於此。</p>
        ) : (
          <ul className="space-y-2 text-sm">
            {auditObservations.map((obs) => (
              <li key={obs.id} className="rounded border border-slate-100 p-3">
                <span className="font-medium">{obs.label}：</span>{obs.content}
                {obs.sourceYear && (
                  <span className="ml-2 text-xs text-amber-600">（源自 {obs.sourceYear} 年）</span>
                )}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  )
}
