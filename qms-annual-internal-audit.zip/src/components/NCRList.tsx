import type { AuditStore } from '../hooks/useAuditStore'
import type { NCRStatus } from '../types'
import { Badge, Card, Select } from './ui/Badge'

const STATUSES: NCRStatus[] = ['開立', '矯正中', '結案']

export function NCRList({ store }: { store: AuditStore }) {
  const { state, updateNCR } = store
  const { company, settings } = state

  return (
    <div className="space-y-6 print-area qr-form">
      <Card>
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">不符合事項清單（QR-28-03）</h2>
            <p className="text-sm text-slate-500">查檢表判定「不符」時自動匯入</p>
          </div>
          <button
            type="button"
            className="no-print rounded-lg border border-slate-300 px-4 py-2 text-sm hover:bg-slate-50"
            onClick={() => window.print()}
          >
            列印
          </button>
        </div>

        <div className="print-only qr-form-header mb-4 text-center">
          <h1 className="text-xl font-bold">{company.name}</h1>
          <p>{settings.auditYear} 不符合事項清單 QR-28-03</p>
        </div>

        {company.ncrs.length === 0 ? (
          <p className="text-sm text-slate-500">目前無不符合事項</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="qr-checklist w-full border-collapse text-sm">
              <thead>
                <tr className="bg-slate-50 text-left">
                  <th className="border p-2">NCR#</th>
                  <th className="border p-2">QP</th>
                  <th className="border p-2">部門</th>
                  <th className="border p-2">流程</th>
                  <th className="border p-2">描述</th>
                  <th className="border p-2">日期</th>
                  <th className="border p-2">狀態</th>
                </tr>
              </thead>
              <tbody>
                {company.ncrs.map((ncr) => (
                  <tr key={ncr.id}>
                    <td className="border p-2 font-mono text-xs">{ncr.ncrNumber}</td>
                    <td className="border p-2">{ncr.qpCode}</td>
                    <td className="border p-2">{ncr.department}</td>
                    <td className="border p-2">{ncr.process}</td>
                    <td className="border p-2">
                      <textarea
                        className="w-full min-w-[200px] rounded border border-slate-200 px-2 py-1 no-print"
                        rows={2}
                        value={ncr.description}
                        onChange={(e) => updateNCR(ncr.id, { description: e.target.value })}
                      />
                      <span className="print-only">{ncr.description}</span>
                    </td>
                    <td className="border p-2">
                      <input
                        type="date"
                        className="rounded border border-slate-200 px-1 no-print"
                        value={ncr.date}
                        onChange={(e) => updateNCR(ncr.id, { date: e.target.value })}
                      />
                      <span className="print-only">{ncr.date}</span>
                    </td>
                    <td className="border p-2">
                      <div className="no-print">
                        <Select
                          value={ncr.status}
                          onChange={(v) => updateNCR(ncr.id, { status: v as NCRStatus })}
                          options={STATUSES.map((s) => ({ value: s, label: s }))}
                        />
                      </div>
                      <span className="print-only"><Badge label={ncr.status} /></span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  )
}
