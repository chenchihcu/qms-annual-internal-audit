import { useRef } from 'react'
import type { AuditStore } from '../hooks/useAuditStore'
import { getSeedStats } from '../data/checklistLoader'
import { Button, Card, Input } from './ui/Badge'

export function SettingsPanel({ store }: { store: AuditStore }) {
  const { state, updateSettings, exportJSON, importJSON, resetToDemo, clearAll } = store
  const fileRef = useRef<HTMLInputElement>(null)

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      try {
        importJSON(reader.result as string)
        alert('匯入成功')
      } catch {
        alert('匯入失敗：JSON 格式錯誤')
      }
    }
    reader.readAsText(file)
    e.target.value = ''
  }

  const handleExport = () => {
    const blob = new Blob([exportJSON()], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `qms-audit-${state.settings.auditYear}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const seedStats = getSeedStats()

  return (
    <div className="space-y-6">
      <Card>
        <h2 className="mb-2 text-lg font-semibold">查檢表種子（114 年度）</h2>
        <p className="text-sm text-slate-600">
          程序列 {seedStats.procedureEntries} · 唯一 QP {seedStats.qpCoverage}/{seedStats.qpTotal} ·
          系統稽核 {seedStats.systemItems} 項 · 製程 {seedStats.processItems} 項 · 型態 {seedStats.configItems} 項 ·
          稽核重點 {seedStats.focusRows} 列
        </p>
      </Card>

      <Card>
        <h2 className="mb-4 text-lg font-semibold">評分規則設定</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          <Input
            label="符合得分"
            type="number"
            value={state.settings.scoringRules.conform}
            onChange={(v) =>
              updateSettings({
                scoringRules: { ...state.settings.scoringRules, conform: Number(v) },
              })
            }
          />
          <Input
            label="不符得分"
            type="number"
            value={state.settings.scoringRules.nonConform}
            onChange={(v) =>
              updateSettings({
                scoringRules: { ...state.settings.scoringRules, nonConform: Number(v) },
              })
            }
          />
          <Input
            label="觀察得分（部分）"
            type="number"
            step="0.1"
            value={state.settings.scoringRules.observation}
            onChange={(v) =>
              updateSettings({
                scoringRules: { ...state.settings.scoringRules, observation: Number(v) },
              })
            }
          />
        </div>
      </Card>

      <Card>
        <h2 className="mb-4 text-lg font-semibold">資料備份與還原</h2>
        <p className="mb-4 text-sm text-slate-500">
          所有資料儲存於瀏覽器 localStorage。建議定期匯出 JSON 備份。
        </p>
        <div className="flex flex-wrap gap-3">
          <Button onClick={handleExport}>匯出 JSON</Button>
          <Button variant="secondary" onClick={() => fileRef.current?.click()}>
            匯入 JSON
          </Button>
          <input ref={fileRef} type="file" accept=".json" className="hidden" onChange={handleImport} />
          <Button variant="secondary" onClick={() => {
            if (confirm('確定還原為示範資料？')) resetToDemo()
          }}>
            還原示範資料
          </Button>
          <Button variant="danger" onClick={() => {
            if (confirm('確定清除所有資料？此操作無法復原。')) clearAll()
          }}>
            清除全部資料
          </Button>
        </div>
      </Card>

      <Card>
        <h2 className="mb-2 text-lg font-semibold">關於</h2>
        <p className="text-sm text-slate-600">
          QMS 年度內部稽核系統 v2.0 — 程序導向（QP 查檢表）、雙公司切換、
          對應 QR-28-01/02/03/04/05 及 QR-02-01 風險矩陣。
          目前公司：{state.company.name}
        </p>
      </Card>
    </div>
  )
}
