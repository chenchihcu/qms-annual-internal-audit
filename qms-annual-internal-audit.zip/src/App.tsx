import { useState } from 'react'
import { useAuditStore } from './hooks/useAuditStore'
import type { CompanyId, TabId } from './types'
import { COMPANY_LABELS } from './types'
import { Dashboard } from './components/Dashboard'
import { AnnualPlan } from './components/AnnualPlan'
import { ProcedureAuditPanel } from './components/ProcedureAuditPanel'
import { NCRList } from './components/NCRList'
import { Observations } from './components/Observations'
import { Suggestions } from './components/Suggestions'
import { PreAuditPrep } from './components/PreAuditPrep'
import { RiskAssessment } from './components/RiskAssessment'
import { SettingsPanel } from './components/SettingsPanel'

const TABS: { id: TabId; label: string }[] = [
  { id: 'dashboard', label: '儀表板' },
  { id: 'plan', label: '年度計畫' },
  { id: 'audit', label: '程序稽核' },
  { id: 'ncr', label: '不符合' },
  { id: 'observations', label: '觀察事項' },
  { id: 'suggestions', label: '建議追蹤' },
  { id: 'prep', label: '稽核前準備' },
  { id: 'risk', label: '風險評估' },
  { id: 'settings', label: '設定' },
]

function App() {
  const store = useAuditStore()
  const [tab, setTab] = useState<TabId>('dashboard')
  const { settings, activeCompanyId, company } = store.state

  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white no-print">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold text-slate-900">QMS 年度內部稽核系統</h1>
              <p className="text-sm text-slate-500">
                {company.name} · {settings.auditYear} 年 · 主任稽核員：{settings.leadAuditor || '—'}
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex rounded-lg border border-slate-300 p-0.5">
                {(Object.keys(COMPANY_LABELS) as CompanyId[]).map((id) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => store.switchCompany(id)}
                    className={`rounded-md px-3 py-1.5 text-sm font-medium transition ${
                      activeCompanyId === id
                        ? 'bg-blue-700 text-white'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {COMPANY_LABELS[id]}
                  </button>
                ))}
              </div>
              <button
                type="button"
                className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm hover:bg-slate-50"
                onClick={() => window.print()}
              >
                列印目前頁面
              </button>
            </div>
          </div>
          <nav className="mt-4 flex gap-1 overflow-x-auto">
            {TABS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={`shrink-0 rounded-lg px-4 py-2 text-sm font-medium transition ${
                  tab === t.id
                    ? 'bg-blue-700 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {t.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        {tab === 'dashboard' && <Dashboard state={store.state} />}
        {tab === 'plan' && <AnnualPlan store={store} />}
        {tab === 'audit' && <ProcedureAuditPanel store={store} />}
        {tab === 'ncr' && <NCRList store={store} />}
        {tab === 'observations' && <Observations store={store} />}
        {tab === 'suggestions' && <Suggestions store={store} />}
        {tab === 'prep' && <PreAuditPrep store={store} />}
        {tab === 'risk' && <RiskAssessment store={store} />}
        {tab === 'settings' && <SettingsPanel store={store} />}
      </main>

      <footer className="border-t border-slate-200 py-4 text-center text-xs text-slate-400 no-print">
        ISO 9001 / AS9100D 內部稽核 · 對應 QR-28-01/02/03/04/05 · 資料儲存於本機
      </footer>
    </div>
  )
}

export default App
